package softuni.exam.constants;

public enum Messages {
    ;
    public final static String INVALID_COUNTRY = "Invalid country%n";
    public final static String VALID_COUNTRY_FORMAT = "Successfully imported country %s - %s%n";

    public final static String INVALID_CITY = "Invalid country%n";
    public final static String VALID_CITY_FORMAT = "Successfully imported city %s - %d%n";
     public final static String INVALID_FORECAST = "Invalid forecast%n";
    public final static String VALID_CITY_FORECAST = "Successfully imported forecast %s - %.2f%n";


}
